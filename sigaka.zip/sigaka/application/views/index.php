<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                asdas
            </div>
            <div class="card-body">
                asdas
            </div>
        </div>
    </div>
</div>